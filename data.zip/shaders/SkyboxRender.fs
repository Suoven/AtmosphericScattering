#version 400 core
out vec4 FragColor;

in vec3 TexCoords;

uniform samplerCube skybox;

uniform float top_atm;
uniform float planet_radius;
uniform vec3 planet_center;
uniform vec3 sun_direction;
uniform vec3 camPos;
uniform mat4 PerspToView;
uniform mat4 ViewToWorld;
uniform vec2 size;


void main()
{    
    //compute the UV 
    vec2 UV = vec2(gl_FragCoord.x / size.x, gl_FragCoord.y / size.y);
    vec2 XY = UV * 2.0f - 1.0f;
    float Z = 0.0f;

    //compute the view position
    vec4 persp_pos = PerspToView * vec4(XY.x, XY.y, Z, 1.0f);
    vec3 view_pos = persp_pos.xyz / persp_pos.w;
    vec3 world_pos = (ViewToWorld * vec4(view_pos, 1.0f)).rgb;

    
    vec3 cam_to_planet = normalize(camPos - planet_center);
    vec3 space_to_planet = normalize(world_pos - planet_center);
    float cam_dist = length(camPos - planet_center);

    float height_scale = (cam_dist - (planet_radius + top_atm * 0.6f)) / top_atm;
    float cam_sun_cangle = -dot(normalize(-sun_direction), cam_to_planet);
    float space_sun_cangle = -dot(normalize(-sun_direction), space_to_planet) * 0.5f + 0.5f;
    float angle_scale = cam_sun_cangle * space_sun_cangle * 10.0f;

    float result = max(height_scale, angle_scale);

    if(result > 0.0f)
    {
         result = clamp(result, 0.0f, 1.0f);
         FragColor = texture(skybox, TexCoords) * result;
    }
    else
        FragColor = vec4(0.0f, 0.0f, 0.0f, 1.0f);
}