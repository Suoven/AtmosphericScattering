#version 400 core



void main()
{      
}