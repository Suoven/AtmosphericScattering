#version 400 core

out vec4 FragColor;

void main()
{             
     //store the final blurred pixel
     FragColor = vec4(2.0f, 2.0f, 2.0f, 1.0);
}